# Applying the StemLab comprehensive-analysis patch

This patch is audited against:

`d0846004356510f83659c68bffe7b92efcf3bcd7`

From a checkout at that commit:

```bash
python apply_upgrade.py /path/to/stemlab
```

The applier checks `git rev-parse HEAD` and refuses a different commit unless you explicitly
pass `--force`. It then copies the audited replacement/new files, patches the existing web
assets/README/reference fixtures, copies the bundled Arcadians cover into the package web assets,
and validates the result.

Validation includes:

```text
python -m compileall -q src tests
pytest -q                         # when pytest is installed
node --check web JS              # when node is installed
git diff --check                 # in a git checkout
```

Then review normally:

```bash
git status
git diff --stat
git diff
```

Install the normal upgraded stack:

```bash
pip install -e ".[all]"
```

Optional research/runtime routes:

```bash
pip install -e ".[semantic-nc]"  # MuQ-MuLan; CC-BY-NC public weights
pip install -e ".[amt]"          # Basic Pitch; Python < 3.12
```

Author: Kieran Simkin — https://kieransimkin.co.uk/  
My Songs: https://kieransimkin.co.uk/my-songs/  
Arcadians EPK: https://kieransimkin.co.uk/arcadians/
