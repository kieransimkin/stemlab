#!/usr/bin/env python3
"""Apply the StemLab v0.2.1 comprehensive-analysis upgrade to a StemLab checkout.

Designed for base commit d0846004356510f83659c68bffe7b92efcf3bcd7 (2026-09-25).
The script is intentionally deterministic and refuses a different Git HEAD unless
--force is supplied. It never downloads model weights; those remain lazy upstream
runtime downloads exactly like StemLab's existing separators.
"""
from __future__ import annotations

import argparse
import importlib.util
import json
import shutil
import subprocess
import sys
from pathlib import Path

EXPECTED_BASE = "d0846004356510f83659c68bffe7b92efcf3bcd7"
KIT = Path(__file__).resolve().parent

REPLACEMENTS = [
    "UPGRADE_NOTES.md",
    ".github/workflows/release.yml",
    "docker/Dockerfile",
    "docker/requirements.lock.txt",
    "docker/verify-environment.sh",
    "pyproject.toml",
    "scripts/release_manifest.py",
    "src/stemlab/__init__.py",
    "src/stemlab/branding.py",
    "src/stemlab/canonical.py",
    "src/stemlab/cli.py",
    "src/stemlab/pipeline.py",
    "src/stemlab/types.py",
    "src/stemlab/analysis/__init__.py",
    "src/stemlab/analysis/audio_features.py",
    "src/stemlab/analysis/harmony.py",
    "src/stemlab/analysis/lyrics.py",
    "src/stemlab/analysis/registry.py",
    "src/stemlab/analysis/rhythm.py",
    "src/stemlab/analysis/runner.py",
    "src/stemlab/analysis/semantic_audio.py",
    "src/stemlab/analysis/semantic_text.py",
    "src/stemlab/analysis/song_map.py",
    "src/stemlab/analysis/structure.py",
    "src/stemlab/analysis/transcription.py",
    "src/stemlab/web/index.html",
]

TESTS = [
    "tests/test_branding.py",
    "tests/test_analysis_registry.py",
    "tests/test_canonical_extended.py",
    "tests/test_deep_harmony.py",
    "tests/test_deep_lyrics.py",
    "tests/test_deep_sonic_rhythm.py",
    "tests/test_song_map.py",
]

ARCADIANS_SECTIONS = [
    {"start": 0.0, "end": 57.46, "label": "Intro"},
    {"start": 57.46, "end": 70.82, "label": "Verse 1"},
    {"start": 70.82, "end": 85.0, "label": "Pre-Chorus"},
    {"start": 85.0, "end": 104.01, "label": "Build 1"},
    {"start": 104.01, "end": 133.94, "label": "Drop 1"},
    {"start": 133.94, "end": 154.44, "label": "Post-Drop"},
    {"start": 154.44, "end": 167.75, "label": "Verse 2"},
    {"start": 167.75, "end": 187.54, "label": "Build 2"},
    {"start": 187.54, "end": 222.10, "label": "Final Drop"},
    {"start": 222.10, "end": 273.604558, "label": "Outro"},
]

ARCADIANS_META = {
    "release_date": "2026-09-25",
    "upc": "882557810017",
    "website": "https://kieransimkin.co.uk/",
    "my_songs_url": "https://kieransimkin.co.uk/my-songs/",
    "epk_url": "https://kieransimkin.co.uk/arcadians/",
    "cover_art_url": "/assets/arcadians-cover.jpg",
    "source_url": "https://github.com/kieransimkin/stemlab",
    "sections": ARCADIANS_SECTIONS,
}


def run_git(root: Path, *args: str) -> str | None:
    try:
        return subprocess.check_output(["git", "-C", str(root), *args], text=True).strip()
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def copy_file(root: Path, rel: str) -> None:
    source = KIT / rel
    target = root / rel
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)


def insert_after(text: str, anchor: str, addition: str) -> str:
    if addition.strip() in text:
        return text
    if anchor not in text:
        raise RuntimeError(f"Could not find insertion anchor: {anchor!r}")
    return text.replace(anchor, anchor + addition, 1)


def patch_style(root: Path) -> None:
    path = root / "src/stemlab/web/style.css"
    snippet = (KIT / "patches/style.append.css").read_text(encoding="utf-8")
    text = path.read_text(encoding="utf-8")
    if "StemLab / Kieran Simkin showcase additions (v0.2)" not in text:
        path.write_text(text.rstrip() + "\n" + snippet.lstrip(), encoding="utf-8")


def patch_app_js(root: Path) -> None:
    path = root / "src/stemlab/web/app.js"
    text = path.read_text(encoding="utf-8")
    if '.replace(/^deep\\//, "Deep · ")' not in text:
        text = text.replace(
            '.replace(/^speech\\//, "Speech · ")\n',
            '.replace(/^speech\\//, "Speech · ")\n    .replace(/^deep\\//, "Deep · ")\n',
            1,
        )

    marker = '    if (path === "speech/whisper.json") {'
    start = text.find(marker)
    if start < 0:
        raise RuntimeError("app.js Whisper insertion point not found")
    generic = '    const lane = this.createLane(key, prettyPath(path), `${ext || "file"}'
    insert_at = text.find(generic, start)
    if insert_at < 0:
        raise RuntimeError("app.js generic artifact insertion point not found")

    deep_block = r'''
    if (path === "deep/structure/structure.json") {
      const lane = this.createLane(key, "Deep · functional structure", "All-In-One · functional song sections", "deep-structure");
      lane.rendered = true;
      this.fetchJson(path).then(data => this.renderSegments(lane.track, data.segments || [])).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/song_map/song_map.json") {
      const lane = this.createLane(key, "Deep · song map", "section-level sonic / rhythm / harmony / lyric fusion", "deep-structure");
      lane.rendered = true;
      this.fetchJson(path).then(data => this.renderSegments(lane.track, data.sections || [])).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/harmony/harmony.json") {
      const lane = this.createLane(key, "Deep · harmony", "collapsed chord progression + key evidence", "deep-harmony");
      lane.rendered = true;
      this.fetchJson(path).then(data => {
        const chords = data.chords?.collapsed_progression || [];
        if (chords.length) this.renderSegments(lane.track, chords);
        else this.renderDeepSummary(lane.track, [
          ["key", data.vamp_key || data.independent_key_candidates_from_nnls_chroma?.[0]?.key || "—"],
          ["tuning", data.tuning_hz ? `${Number(data.tuning_hz).toFixed(1)} Hz` : "—"],
        ]);
      }).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/lyrics/lyrics.json") {
      const lane = this.createLane(key, "Deep · rhyme & prosody", "phonetic rhyme, repetition and delivery", "deep-lyrics");
      lane.rendered = true;
      this.fetchJson(path).then(data => {
        const timed = (data.lines || []).filter(item => Number.isFinite(Number(item.start)) && Number.isFinite(Number(item.end)));
        if (timed.length) this.renderSegments(lane.track, timed.map(item => ({...item, label: item.text})));
        else this.renderDeepSummary(lane.track, [
          ["rhyme scheme", data.rhyme?.scheme || "—"],
          ["lines", data.line_count ?? "—"],
          ["words", data.word_count ?? "—"],
        ]);
      }).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/sonic/sonic.json") {
      const lane = this.createLane(key, "Deep · sonic profile", "loudness · dynamics · timbre · stereo", "feature");
      lane.rendered = true;
      this.fetchJson(path).then(data => this.renderDeepSummary(lane.track, [
        ["LUFS", this.deepNumber(data.loudness?.integrated_lufs_bs1770, 1)],
        ["crest", this.deepNumber(data.loudness?.crest_factor_db, 1, " dB")],
        ["RMS range", this.deepNumber(data.loudness?.short_term_rms_range_db_p95_p10, 1, " dB")],
        ["centroid", this.deepNumber(data.timbre?.spectral_centroid_hz_mean, 0, " Hz")],
        ["stereo corr", this.deepNumber(data.stereo?.left_right_correlation, 2)],
      ])).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/rhythm/rhythm.json") {
      const lane = this.createLane(key, "Deep · groove", "meter · stability · swing · syncopation evidence", "feature");
      lane.rendered = true;
      this.fetchJson(path).then(data => this.renderDeepSummary(lane.track, [
        ["tempo", this.deepNumber(data.tempo?.median_bpm, 2, " BPM")],
        ["meter", data.meter?.estimated_beats_per_bar ? `${data.meter.estimated_beats_per_bar}/4-ish` : "—"],
        ["swing", this.deepNumber(data.groove?.swing_ratio_long_to_short, 2, ":1")],
        ["offbeat energy", this.deepNumber(data.groove?.offbeat_onset_energy_ratio, 3)],
        ["onsets/s", this.deepNumber(data.groove?.onset_density_per_second, 2)],
      ])).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/semantic_text/semantic_text.json") {
      const lane = this.createLane(key, "Deep · lyric semantics", "sentence embedding theme similarities · not probabilities", "feature");
      lane.rendered = true;
      this.fetchJson(path).then(data => this.renderDeepSummary(
        lane.track,
        (data.theme_similarity || []).slice(0, 7).map(item => [item.theme, this.deepNumber(item.similarity, 3)])
      )).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/semantic_audio/semantic_audio.json") {
      const lane = this.createLane(key, "Deep · audio semantics", "MuQ-MuLan zero-shot similarities · CC-BY-NC weights", "feature");
      lane.rendered = true;
      this.fetchJson(path).then(data => {
        const items = Object.entries(data.prompt_sets || {}).flatMap(([category, values]) =>
          (values || []).slice(0, 2).map(item => [`${category}: ${item.prompt}`, this.deepNumber(item.similarity, 3)])
        );
        this.renderDeepSummary(lane.track, items);
      }).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

    if (path === "deep/summary.json") {
      const lane = this.createLane(key, "Deep · analysis summary", "cross-domain action inventory", "feature");
      lane.rendered = true;
      this.fetchJson(path).then(data => {
        const items = Object.entries(data.analyses || {}).map(([name, rec]) => [name, rec.available ? "ready" : "unavailable"]);
        if ((data.errors || []).length) items.push(["errors", data.errors.length]);
        this.renderDeepSummary(lane.track, items);
      }).catch(error => this.renderArtifact(lane.track, path, error.message));
      return;
    }

'''
    if 'path === "deep/structure/structure.json"' not in text:
        text = text[:insert_at] + deep_block + text[insert_at:]

    method_anchor = '  renderArtifact(track, path, note = "") {'
    helpers = r'''  deepNumber(value, digits = 2, suffix = "") {
    const number = Number(value);
    return Number.isFinite(number) ? `${number.toFixed(digits)}${suffix}` : "—";
  }

  renderDeepSummary(track, items) {
    const band = document.createElement("div");
    band.className = "deep-summary-band";
    for (const [label, value] of items || []) {
      if (value === undefined || value === null || value === "") continue;
      const chip = document.createElement("div");
      chip.className = "deep-summary-chip";
      const strong = document.createElement("strong");
      strong.textContent = `${label}: `;
      chip.append(strong, document.createTextNode(String(value)));
      band.appendChild(chip);
    }
    if (!band.children.length) {
      const chip = document.createElement("div");
      chip.className = "deep-summary-chip";
      chip.textContent = "analysis available";
      band.appendChild(chip);
    }
    track.appendChild(band);
  }

'''
    if '  renderDeepSummary(track, items) {' not in text:
        if method_anchor not in text:
            raise RuntimeError("app.js renderArtifact anchor not found")
        text = text.replace(method_anchor, helpers + method_anchor, 1)

    path.write_text(text, encoding="utf-8")


def patch_canonical_js(root: Path) -> None:
    path = root / "src/stemlab/web/canonical.js"
    text = path.read_text(encoding="utf-8")
    if 'const loadArcadiansHero = document.querySelector("#loadArcadiansHero");' not in text:
        text = text.replace(
            'const loadArcadiansReference = document.querySelector("#loadArcadiansReference");\n',
            'const loadArcadiansReference = document.querySelector("#loadArcadiansReference");\nconst loadArcadiansHero = document.querySelector("#loadArcadiansHero");\n',
            1,
        )
    if 'let canonicalReferenceMetadata = {};' not in text:
        text = text.replace(
            'let canonicalBeatSource = null;\n',
            'let canonicalBeatSource = null;\nlet canonicalReferenceMetadata = {};\n',
            1,
        )
    old_return = '''  return {\n    bpm: bpmRaw ? Number(bpmRaw) : null,\n    lyrics: lyrics.trim() || null,\n    lyric_timing: timing.trim() || [],\n  };'''
    new_return = '''  return {\n    ...canonicalReferenceMetadata,\n    bpm: bpmRaw ? Number(bpmRaw) : null,\n    lyrics: lyrics.trim() || null,\n    lyric_timing: timing.trim() || [],\n  };'''
    text = text.replace(old_return, new_return, 1)

    listener_start = text.find('loadArcadiansReference?.addEventListener("click", async event => {')
    if listener_start < 0 and 'async function loadArcadiansFixture' not in text:
        raise RuntimeError("canonical.js Arcadians loader block not found")
    if listener_start >= 0:
        loader = r'''async function loadArcadiansFixture(event) {
  event?.preventDefault();
  event?.stopPropagation();
  try {
    const response = await fetch("/assets/arcadians-reference.json", { cache: "no-store" });
    if (!response.ok) throw new Error(`Could not load Arcadians reference (${response.status})`);
    const reference = await response.json();

    canonicalReferenceMetadata = {};
    for (const field of [
      "title", "artist", "release_date", "isrc", "upc", "website", "my_songs_url",
      "epk_url", "cover_art_url", "source_url", "sections"
    ]) {
      if (reference[field] !== undefined && reference[field] !== null) {
        canonicalReferenceMetadata[field] = reference[field];
      }
    }

    if (canonicalBpmInput) canonicalBpmInput.value = reference.bpm ?? "";
    if (canonicalLyricsInput) canonicalLyricsInput.value = reference.lyrics ?? "";
    if (canonicalTimingInput) {
      canonicalTimingInput.value = Array.isArray(reference.lyric_timing) && reference.lyric_timing.length
        ? JSON.stringify(reference.lyric_timing, null, 2)
        : "";
    }
    const details = document.querySelector(".known-info");
    if (details) details.open = true;
    if (knownInfoStatus) {
      knownInfoStatus.textContent = reference.lyric_timing?.length
        ? `Loaded ${reference.title || "Arcadians"}: canonical release metadata, sections, ${reference.bpm} BPM, lyrics and timing.`
        : `Loaded ${reference.title || "Arcadians"} canonical reference metadata.`;
    }
  } catch (error) {
    if (knownInfoStatus) knownInfoStatus.textContent = error.message;
  }
}

loadArcadiansReference?.addEventListener("click", loadArcadiansFixture);
loadArcadiansHero?.addEventListener("click", loadArcadiansFixture);
'''
        text = text[:listener_start] + loader + "\n"
    path.write_text(text, encoding="utf-8")


def enrich_arcadians(root: Path) -> None:
    for rel in ("examples/arcadians/reference.json", "src/stemlab/web/arcadians-reference.json"):
        path = root / rel
        if not path.exists():
            continue
        value = json.loads(path.read_text(encoding="utf-8"))
        value.update(ARCADIANS_META)
        value.setdefault("title", "Arcadians")
        value.setdefault("artist", "Kieran Simkin")
        value.setdefault("isrc", "QT6EB2639508")
        value.setdefault("bpm", 145.0)
        path.write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")

    cover = root / "examples/arcadians/cover.jpg"
    if cover.exists():
        target = root / "src/stemlab/web/arcadians-cover.jpg"
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(cover, target)


def patch_readme(root: Path) -> None:
    path = root / "README.md"
    text = path.read_text(encoding="utf-8")
    brand = '''\n> **StemLab by [Kieran Simkin](https://kieransimkin.co.uk/)** · [My Songs](https://kieransimkin.co.uk/my-songs/) · [Arcadians EPK](https://kieransimkin.co.uk/arcadians/) · [Source](https://github.com/kieransimkin/stemlab)\n'''
    if "StemLab by [Kieran Simkin]" not in text:
        text = text.replace("# StemLab\n", "# StemLab\n" + brand, 1)

    section = r'''
## Comprehensive sonic, harmonic, rhythmic and semantic analysis

StemLab 0.2 adds a higher-level evidence-fusion pass without discarding any of the
existing low-level outputs. The default deep pass now includes:

| Action | Evidence / model | Main output |
|---|---|---|
| Sonic profile | `pyloudnorm` BS.1770 + librosa DSP | LUFS, dynamics, true-peak estimate, timbre and stereo |
| Groove / meter | all successful beat grids + onset analysis | tempo stability, meter, swing, offbeat energy and quantisation error |
| Harmony | Chordino + NNLS chroma + QM key/tuning | chord progression, harmonic rhythm, key evidence and tonal changes |
| Functional structure | All-In-One-Infer 3.1 | BPM, beats/downbeats and intro/verse/chorus/bridge/outro-style sections |
| Rhyme / prosody | CMU Pronouncing Dictionary + timing | rhyme scheme, internal rhyme, syllables, repetitions and delivery rate |
| Lyric semantics | SentenceTransformers | theme similarity, continuity and unsupervised line clusters |
| Song map | StemLab evidence fusion | section-level sonic/rhythm/chord/lyric summaries on one timeline |

Optional actions include **Basic Pitch** polyphonic MIDI/note transcription on isolated
instrument stems and **MuQ-MuLan** zero-shot audio/text semantics. MuQ-MuLan's released
weights are CC-BY-NC 4.0, so that route is deliberately opt-in and its licence is embedded
in every result. Embedding similarities are labelled as similarities, never probabilities.

Inspect the routes and their dependencies with:

```bash
stemlab analysis-actions
```

Useful switches include `--no-structure`, `--no-text-semantics`, `--audio-semantics`,
`--basic-pitch`, and `--all-in-one-embeddings`.

The derived artifacts live under `deep/` (`sonic/`, `rhythm/`, `harmony/`, `structure/`,
`lyrics/`, `semantic_text/`, optional `semantic_audio/` and `basic_pitch/`, plus
`song_map/song_map.json` and `summary.json`).

'''
    if "## Comprehensive sonic, harmonic, rhythmic and semantic analysis" not in text:
        text = text.replace("## Install\n", section + "## Install\n", 1)

    arc = '''\nThe bundled **Arcadians** reference is intentionally a dual showcase: it demonstrates\nStemLab against artist-supplied ground truth while also presenting the release itself.\nSee the official [Arcadians EPK](https://kieransimkin.co.uk/arcadians/) and\n[Kieran Simkin's full My Songs catalogue](https://kieransimkin.co.uk/my-songs/).\nThe web demo carries canonical release metadata and artist-edited structural waypoints,\nso learned section boundaries can be compared against the authoritative song map.\n'''
    if "dual showcase" not in text and "`examples/arcadians/`" in text:
        needle = "`examples/arcadians/` contains"
        pos = text.find(needle)
        if pos >= 0:
            paragraph_end = text.find("\n\n", pos)
            if paragraph_end >= 0:
                text = text[:paragraph_end] + "\n" + arc + text[paragraph_end:]
    path.write_text(text, encoding="utf-8")


def prepend_brand(path: Path) -> None:
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    marker = "**Kieran Simkin** · https://kieransimkin.co.uk/"
    if marker in text:
        return
    block = (
        "\n> **Kieran Simkin** · https://kieransimkin.co.uk/ · "
        "My Songs: https://kieransimkin.co.uk/my-songs/ · "
        "Arcadians: https://kieransimkin.co.uk/arcadians/ · "
        "Source: https://github.com/kieransimkin/stemlab\n\n"
    )
    first_newline = text.find("\n")
    if first_newline >= 0:
        text = text[: first_newline + 1] + block + text[first_newline + 1 :]
    else:
        text += block
    path.write_text(text, encoding="utf-8")


def patch_arcadians_readme(root: Path) -> None:
    path = root / "examples/arcadians/README.md"
    if not path.exists():
        return
    text = path.read_text(encoding="utf-8")
    if "## Official Arcadians release links" not in text:
        text += '''\n## Official Arcadians release links\n\n- EPK / song page: https://kieransimkin.co.uk/arcadians/\n- Kieran Simkin: https://kieransimkin.co.uk/\n- Full catalogue: https://kieransimkin.co.uk/my-songs/\n- Release date: **25 September 2026**\n- BPM: **145**\n- ISRC: **QT6EB2639508**\n- UPC: **882557810017**\n\nThe reference fixture also includes the artist's canonical section map: Intro → Verse 1 →\nPre-Chorus → Build 1 → Drop 1 → Post-Drop → Verse 2 → Build 2 → Final Drop → Outro.\nStemLab's All-In-One output is retained separately so machine boundaries can be compared\nwith—not substituted for—the artist-authored structure.\n'''
    path.write_text(text, encoding="utf-8")


def _module_available(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except (ImportError, AttributeError, ValueError):
        return False


def validate(root: Path) -> None:
    # Always validate syntax with the same interpreter that is running the
    # applier.  Do not accidentally pick up a global ``python``/``pytest``
    # executable outside the active StemLab virtual environment.
    subprocess.run(
        [sys.executable, "-m", "compileall", "-q", "src", "tests"],
        cwd=root,
        check=True,
    )

    # The existing StemLab suite contains web/server tests whose modules are
    # optional in pyproject.toml.  A source patch must not report a failed
    # upgrade merely because the current environment was installed without
    # ``.[server]``.  Run the complete suite only when its import-time server
    # dependencies are available.  Otherwise run the new focused non-server
    # tests when the default v0.2 analysis dependencies are installed, and
    # print the exact command needed for full validation.
    if _module_available("pytest"):
        server_ready = all(_module_available(name) for name in ("fastapi", "socketio"))
        analysis_ready = all(
            _module_available(name)
            for name in ("numpy", "scipy", "soundfile", "librosa", "pyloudnorm")
        )

        if server_ready:
            subprocess.run(
                [sys.executable, "-m", "pytest", "-q"],
                cwd=root,
                check=True,
            )
        elif analysis_ready:
            focused = [str(Path(test)) for test in TESTS]
            subprocess.run(
                [sys.executable, "-m", "pytest", "-q", *focused],
                cwd=root,
                check=True,
            )
            print(
                "NOTE: Full repository pytest validation skipped because the "
                "optional server dependencies are not installed.\n"
                f"      Run: {sys.executable} -m pip install -e \".[dev,server]\"\n"
                f"      Then: {sys.executable} -m pytest -q"
            )
        else:
            print(
                "NOTE: Pytest validation skipped because this existing environment "
                "has not yet installed the upgraded package dependencies.\n"
                f"      Run: {sys.executable} -m pip install -e \".[dev,server]\"\n"
                f"      Then: {sys.executable} -m pytest -q"
            )
    else:
        print(
            "NOTE: pytest is not installed; syntax validation completed.\n"
            f"      For the full suite run: {sys.executable} -m pip install -e \".[dev,server]\""
        )

    # JS syntax validation when Node is available.
    node = shutil.which("node")
    if node:
        subprocess.run([node, "--check", "src/stemlab/web/app.js"], cwd=root, check=True)
        subprocess.run([node, "--check", "src/stemlab/web/canonical.js"], cwd=root, check=True)
    if (root / ".git").exists() and shutil.which("git"):
        subprocess.run(["git", "diff", "--check"], cwd=root, check=True)


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("repository", type=Path, help="Path to a StemLab checkout")
    parser.add_argument("--force", action="store_true", help="Apply even when Git HEAD differs from the audited base")
    parser.add_argument("--no-validate", action="store_true")
    args = parser.parse_args()
    root = args.repository.expanduser().resolve()
    if not (root / "pyproject.toml").is_file() or not (root / "src/stemlab").is_dir():
        parser.error(f"Not a StemLab checkout: {root}")

    head = run_git(root, "rev-parse", "HEAD")
    if head and head != EXPECTED_BASE and not args.force:
        parser.error(
            f"Checkout is at {head}, but this kit was audited against {EXPECTED_BASE}. "
            "Rebase/review or rerun with --force."
        )

    for rel in REPLACEMENTS + TESTS:
        copy_file(root, rel)
    patch_style(root)
    patch_app_js(root)
    patch_canonical_js(root)
    enrich_arcadians(root)
    patch_readme(root)
    for rel in ("START_WEB.md", "CONTAINERS.md", "docker/README.md"):
        prepend_brand(root / rel)
    patch_arcadians_readme(root)

    if not args.no_validate:
        validate(root)

    print("StemLab comprehensive-analysis upgrade applied (patch revision 0.2.1).")
    print("Author: Kieran Simkin — https://kieransimkin.co.uk/")
    print("My Songs: https://kieransimkin.co.uk/my-songs/")
    print("Arcadians: https://kieransimkin.co.uk/arcadians/")
    if head:
        print(f"Audited base: {EXPECTED_BASE}; checkout before apply: {head}")
    print("Review with: git diff --stat && git diff")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
