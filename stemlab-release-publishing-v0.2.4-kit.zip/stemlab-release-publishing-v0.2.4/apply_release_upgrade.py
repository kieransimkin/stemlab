#!/usr/bin/env python
from __future__ import annotations

import argparse
import subprocess
import sys
from pathlib import Path

WORKFLOW = 'name: Release\n\non:\n  push:\n    tags: ["v*"]\n  workflow_dispatch:\n\n# Default to read-only. Jobs opt into only the permissions they need.\npermissions:\n  contents: read\n\njobs:\n  release-build:\n    name: Build and validate release\n    runs-on: ubuntu-22.04\n    steps:\n      - uses: actions/checkout@v7\n\n      - uses: actions/setup-python@v7\n        with:\n          python-version: "3.10"\n          cache: pip\n\n      - name: Native build requirements\n        run: |\n          sudo apt-get update\n          sudo apt-get install -y build-essential patchelf libsndfile1 ffmpeg\n\n      - name: Install Python build/runtime dependencies\n        run: |\n          python -m pip install -U pip wheel setuptools\n          # madmom/BeatNet remain legacy-sensitive; preinstall Cython before resolving extras.\n          python -m pip install \'Cython<3\' \'numpy<2\'\n          python -m pip install -e \'.[all,binary,dev]\'\n          python -m pip install -U build twine\n\n      - name: Verify release tag matches package version\n        if: startsWith(github.ref, \'refs/tags/v\')\n        run: |\n          python - <<\'PY\'\n          import importlib.metadata\n          import os\n\n          tag = os.environ["GITHUB_REF_NAME"]\n          expected = tag[1:] if tag.startswith("v") else tag\n          actual = importlib.metadata.version("stemlab")\n          if actual != expected:\n              raise SystemExit(\n                  f"Release tag {tag!r} does not match StemLab package version {actual!r}"\n              )\n          print(f"Release version verified: {actual}")\n          PY\n\n      - name: Test package before release build\n        run: |\n          python -m compileall -q src tests\n          pytest\n          ruff check src tests scripts\n\n      - name: Build wheel and sdist\n        run: |\n          python -m build\n          python -m twine check dist/*\n\n      - name: Build self-contained one-file CLI\n        run: |\n          python -m nuitka \\\n            --onefile \\\n            --assume-yes-for-downloads \\\n            --output-dir=build/nuitka \\\n            --output-filename=stemlab-linux-x86_64 \\\n            --include-package=stemlab \\\n            --include-package=demucs \\\n            --include-package=openunmix \\\n            --include-package=bs_roformer \\\n            --include-package=faster_whisper \\\n            --include-package=beat_this \\\n            --include-package=BeatNet \\\n            --include-package=librosa \\\n            --include-package=pyloudnorm \\\n            --include-package=cmudict \\\n            --include-package=sentence_transformers \\\n            --include-package=allin1_infer \\\n            --include-package-data=bs_roformer \\\n            --include-package-data=faster_whisper \\\n            src/stemlab/__main__.py\n\n      - name: Assemble release directory and manifest\n        run: |\n          mkdir -p dist-release\n          cp dist/* dist-release/\n          cp build/nuitka/stemlab-linux-x86_64 dist-release/\n          chmod +x dist-release/stemlab-linux-x86_64\n          cat > dist-release/STEMLAB-ABOUT.txt <<\'EOF\'\n          StemLab\n          =======\n          Author: Kieran Simkin\n          Website: https://kieransimkin.co.uk/\n          My Songs: https://kieransimkin.co.uk/my-songs/\n          Arcadians showcase: https://kieransimkin.co.uk/arcadians/\n          Source: https://github.com/kieransimkin/stemlab\n\n          StemLab performs multi-model music source separation plus sonic,\n          harmonic, rhythmic, structural, lyrical and semantic analysis.\n          EOF\n          python scripts/release_manifest.py dist-release\n          cat dist-release/SHA256SUMS\n\n      - name: Upload Python distributions\n        uses: actions/upload-artifact@v4\n        with:\n          name: python-package-distributions\n          path: |\n            dist/*.whl\n            dist/*.tar.gz\n          if-no-files-found: error\n\n      - name: Upload complete release assets\n        uses: actions/upload-artifact@v4\n        with:\n          name: stemlab-release-assets\n          path: dist-release/*\n          if-no-files-found: error\n\n  github-release:\n    name: Publish GitHub Release\n    if: startsWith(github.ref, \'refs/tags/v\')\n    needs: release-build\n    runs-on: ubuntu-24.04\n    permissions:\n      contents: write\n    steps:\n      - name: Retrieve release assets\n        uses: actions/download-artifact@v5\n        with:\n          name: stemlab-release-assets\n          path: dist-release\n\n      - name: Create or update GitHub Release\n        env:\n          GH_TOKEN: ${{ github.token }}\n          TAG: ${{ github.ref_name }}\n          REPOSITORY: ${{ github.repository }}\n        run: |\n          if ! gh release view "$TAG" --repo "$REPOSITORY" >/dev/null 2>&1; then\n            gh release create "$TAG" \\\n              --repo "$REPOSITORY" \\\n              --verify-tag \\\n              --title "StemLab ${TAG#v}" \\\n              --generate-notes\n          fi\n\n          gh release view "$TAG" --repo "$REPOSITORY" --json body -q .body > /tmp/release-body.md\n          if ! grep -q \'kieransimkin.co.uk/my-songs/\' /tmp/release-body.md; then\n            cat >> /tmp/release-body.md <<\'EOF\'\n\n          ---\n          **StemLab by Kieran Simkin**\n\n          Website: https://kieransimkin.co.uk/\n          Music catalogue: https://kieransimkin.co.uk/my-songs/\n          Arcadians showcase: https://kieransimkin.co.uk/arcadians/\n          Source: https://github.com/kieransimkin/stemlab\n          EOF\n            gh release edit "$TAG" --repo "$REPOSITORY" --notes-file /tmp/release-body.md\n          fi\n\n          gh release upload "$TAG" dist-release/* \\\n            --repo "$REPOSITORY" \\\n            --clobber\n\n  pypi-publish:\n    name: Publish Python distributions to PyPI\n    if: startsWith(github.ref, \'refs/tags/v\')\n    needs: release-build\n    runs-on: ubuntu-24.04\n    environment:\n      name: pypi\n      url: https://pypi.org/p/stemlab\n    permissions:\n      id-token: write\n    steps:\n      - name: Retrieve Python distributions\n        uses: actions/download-artifact@v5\n        with:\n          name: python-package-distributions\n          path: dist\n\n      - name: Publish to PyPI with Trusted Publishing\n        uses: pypa/gh-action-pypi-publish@release/v1\n'
PYPI_DOC = '# Publishing StemLab\n\nStemLab release publishing is driven by version tags.\n\n## Destinations\n\nA successful version tag such as `v0.2.0` publishes:\n\n- Python wheel + sdist to PyPI.\n- Wheel, sdist, Linux one-file CLI, checksums, release manifest and attribution file to GitHub Releases.\n- Container images to GitHub Container Registry (GHCR).\n- Container images to Docker Hub when `DOCKERHUB_USERNAME` and `DOCKERHUB_TOKEN` are configured.\n\nThe existing CI workflow handles the container registries. `.github/workflows/release.yml`\nhandles PyPI and GitHub Release artifacts.\n\n## One-time PyPI Trusted Publisher setup\n\nStemLab uses PyPI Trusted Publishing (OIDC), so there is no long-lived PyPI API\ntoken in GitHub Secrets.\n\nAt the time this workflow was added, `https://pypi.org/project/stemlab/` did not\nexist. Configure a **pending publisher** in your PyPI account before pushing the\nfirst version tag.\n\nUse these exact values:\n\n| Field | Value |\n| --- | --- |\n| PyPI project name | `stemlab` |\n| GitHub owner | `kieransimkin` |\n| GitHub repository | `stemlab` |\n| Workflow filename | `release.yml` |\n| Environment | `pypi` |\n\nIn PyPI, open your account\'s **Publishing** page and add a pending GitHub\npublisher with those values. On the first successful upload PyPI creates the\nproject and converts the pending publisher to a normal Trusted Publisher.\n\nThe workflow grants `id-token: write` only to the PyPI publication job.\n\n## GitHub environment\n\nThe release workflow references the GitHub environment `pypi`. GitHub can create\nan environment when a workflow first references it, but it is preferable to\ncreate it explicitly in:\n\n`Repository Settings -> Environments -> New environment -> pypi`\n\nFor stronger release protection, add required reviewers to that environment.\n\n## Releasing v0.2.0\n\nThe package version in `pyproject.toml` must match the tag without the leading\n`v`. The workflow refuses to publish when they differ.\n\nFor the current package:\n\n```bash\ngit pull\ngit status\ngit tag -a v0.2.0 -m "StemLab 0.2.0"\ngit push origin v0.2.0\n```\n\nThat tag starts both workflows:\n\n1. **CI**: tests and publishes GHCR + Docker Hub version tags.\n2. **Release**: tests again, builds package/binary artifacts, creates the GitHub\n   Release, and publishes the Python distributions to PyPI through OIDC.\n\nFor a `v0.2.0` tag, the container metadata workflow is configured to produce the\nversion tag/semantic aliases plus `latest`.\n\n## Manual workflow runs\n\n`workflow_dispatch` intentionally builds and validates release artifacts but\ndoes **not** publish to PyPI or create a GitHub Release. Publishing requires a\n`v*` Git tag.\n\n## Release metadata\n\nPublished package and release material carries:\n\n- Author: Kieran Simkin\n- Website: https://kieransimkin.co.uk/\n- My Songs: https://kieransimkin.co.uk/my-songs/\n- Arcadians showcase: https://kieransimkin.co.uk/arcadians/\n- Source: https://github.com/kieransimkin/stemlab\n'

def run(cmd: list[str], cwd: Path) -> None:
    print("+", " ".join(cmd))
    subprocess.run(cmd, cwd=cwd, check=True)

def main() -> int:
    parser = argparse.ArgumentParser(
        description="StemLab v0.2.4 release publishing upgrade (GitHub Releases + PyPI Trusted Publishing)."
    )
    parser.add_argument("repository", nargs="?", default=".")
    parser.add_argument("--no-validate", action="store_true")
    args = parser.parse_args()

    root = Path(args.repository).expanduser().resolve()
    if not (root / ".git").exists() or not (root / "pyproject.toml").is_file():
        parser.error(f"Not a StemLab checkout: {root}")

    pyproject = root / "pyproject.toml"
    text = pyproject.read_text(encoding="utf-8")
    if 'name = "stemlab"' not in text:
        parser.error(f"Not a StemLab pyproject: {pyproject}")

    # Declare the Python floor used by CI and remove uv's "requires-python" warning.
    if "requires-python" not in text:
        marker = 'readme = "README.md"\n'
        if marker not in text:
            raise SystemExit("Could not locate the pyproject readme field.")
        text = text.replace(marker, marker + 'requires-python = ">=3.10"\n', 1)
        pyproject.write_text(text, encoding="utf-8", newline="\n")
        print("updated: pyproject.toml (requires-python >=3.10)")
    else:
        print("already has requires-python: pyproject.toml")

    workflow_path = root / ".github" / "workflows" / "release.yml"
    workflow_path.parent.mkdir(parents=True, exist_ok=True)
    workflow_path.write_text(WORKFLOW, encoding="utf-8", newline="\n")
    print("updated: .github/workflows/release.yml")

    doc_path = root / "PYPI_PUBLISHING.md"
    doc_path.write_text(PYPI_DOC, encoding="utf-8", newline="\n")
    print("added/updated: PYPI_PUBLISHING.md")

    if args.no_validate:
        print("Validation skipped.")
        return 0

    # Validate TOML using the active Python when available.
    if sys.version_info >= (3, 11):
        run([sys.executable, "-c",
             "import pathlib,tomllib; tomllib.loads(pathlib.Path('pyproject.toml').read_text(encoding='utf-8')); print('pyproject.toml: OK')"], root)

    # Parse the workflow when PyYAML happens to be installed, without making it a requirement.
    subprocess.run(
        [sys.executable, "-c",
         "import importlib.util, pathlib; "
         "s=importlib.util.find_spec('yaml'); "
         "exec(\"import yaml; yaml.safe_load(pathlib.Path('.github/workflows/release.yml').read_text(encoding='utf-8')); print('release.yml: YAML OK')\") if s else print('release.yml: PyYAML unavailable; syntax will be checked by GitHub Actions')"],
        cwd=root,
        check=True,
    )

    run(["git", "diff", "--check"], root)
    print("\nStemLab v0.2.4 publishing upgrade applied successfully.")
    print("Next: configure the pending PyPI Trusted Publisher described in PYPI_PUBLISHING.md, commit/push, then tag v0.2.0.")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
