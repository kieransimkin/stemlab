# Publishing StemLab

StemLab release publishing is driven by version tags.

## Destinations

A successful version tag such as `v0.2.0` publishes:

- Python wheel + sdist to PyPI.
- Wheel, sdist, Linux one-file CLI, checksums, release manifest and attribution file to GitHub Releases.
- Container images to GitHub Container Registry (GHCR).
- Container images to Docker Hub when `DOCKERHUB_USERNAME` and `DOCKERHUB_TOKEN` are configured.

The existing CI workflow handles the container registries. `.github/workflows/release.yml`
handles PyPI and GitHub Release artifacts.

## One-time PyPI Trusted Publisher setup

StemLab uses PyPI Trusted Publishing (OIDC), so there is no long-lived PyPI API
token in GitHub Secrets.

At the time this workflow was added, `https://pypi.org/project/stemlab/` did not
exist. Configure a **pending publisher** in your PyPI account before pushing the
first version tag.

Use these exact values:

| Field | Value |
| --- | --- |
| PyPI project name | `stemlab` |
| GitHub owner | `kieransimkin` |
| GitHub repository | `stemlab` |
| Workflow filename | `release.yml` |
| Environment | `pypi` |

In PyPI, open your account's **Publishing** page and add a pending GitHub
publisher with those values. On the first successful upload PyPI creates the
project and converts the pending publisher to a normal Trusted Publisher.

The workflow grants `id-token: write` only to the PyPI publication job.

## GitHub environment

The release workflow references the GitHub environment `pypi`. GitHub can create
an environment when a workflow first references it, but it is preferable to
create it explicitly in:

`Repository Settings -> Environments -> New environment -> pypi`

For stronger release protection, add required reviewers to that environment.

## Releasing v0.2.0

The package version in `pyproject.toml` must match the tag without the leading
`v`. The workflow refuses to publish when they differ.

For the current package:

```bash
git pull
git status
git tag -a v0.2.0 -m "StemLab 0.2.0"
git push origin v0.2.0
```

That tag starts both workflows:

1. **CI**: tests and publishes GHCR + Docker Hub version tags.
2. **Release**: tests again, builds package/binary artifacts, creates the GitHub
   Release, and publishes the Python distributions to PyPI through OIDC.

For a `v0.2.0` tag, the container metadata workflow is configured to produce the
version tag/semantic aliases plus `latest`.

## Manual workflow runs

`workflow_dispatch` intentionally builds and validates release artifacts but
does **not** publish to PyPI or create a GitHub Release. Publishing requires a
`v*` Git tag.

## Release metadata

Published package and release material carries:

- Author: Kieran Simkin
- Website: https://kieransimkin.co.uk/
- My Songs: https://kieransimkin.co.uk/my-songs/
- Arcadians showcase: https://kieransimkin.co.uk/arcadians/
- Source: https://github.com/kieransimkin/stemlab
